export const LANGUAGES = {
  RU: "ru",
  EN: "en",
} as const;
