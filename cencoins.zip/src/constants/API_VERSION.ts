export const API_VERSION = {
  V1: "v1",
  V2: "v2",
} as const;
