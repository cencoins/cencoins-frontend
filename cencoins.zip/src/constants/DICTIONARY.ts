export const DICTIONARY = {
  COMMON: "common",
} as const;
