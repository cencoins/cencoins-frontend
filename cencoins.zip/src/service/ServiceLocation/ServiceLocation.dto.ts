export interface GetLocationParams {
  ip: string;
}

export interface GetLocationResponse {
  location: string;
  lang: string;
}
